<?php
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_1_1($module) {
 return $module->upgradeSchema() && $module->repairAdminTab();
}
