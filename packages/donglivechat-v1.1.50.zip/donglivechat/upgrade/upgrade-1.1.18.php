<?php
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_1_18($module) { return $module->upgradeSchema(); }
